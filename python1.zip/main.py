import base64
import functions_framework
from google.cloud import bigquery
from google.api_core.exceptions import Conflict  
from datetime import datetime
import json

@functions_framework.cloud_event
def hello_pubsub(cloud_event):
    # Initialize BigQuery client
    project_id = 'cs-host-250323f4c1e749beab0804'
    dataset_id = 'order_management'
    client = bigquery.Client()

    try:
        # Decode and parse Pub/Sub message
        pubsub_message = base64.b64decode(cloud_event.data["message"]["data"])
        json_data = json.loads(pubsub_message.decode('utf-8'))

        # Extract table name and records
        table_name = json_data.get("table_name")
        records = json_data.get("data", [])

        if not table_name or not records:
            print("Invalid JSON format. Missing 'table_name' or 'data'.")
            return

        # Create schema dynamically from first record
        first_record = records[0]
        schema = [
            bigquery.SchemaField(key, "STRING" if isinstance(value, str) else
                                 "INTEGER" if isinstance(value, int) else
                                 "FLOAT" if isinstance(value, float) else
                                 "DATETIME" if isinstance(value, str) and "T" in value else
                                 "STRING")
            for key, value in first_record.items()
        ]

        # Reference and attempt to create table
        table_ref = client.dataset(dataset_id).table(table_name)
        table = bigquery.Table(table_ref, schema=schema)

        try:
            client.create_table(table)
            print(f"Table {table_name} created successfully.")
        except Conflict:
            print(f"Table {table_name} already exists.")

        # Insert records into table
        errors = client.insert_rows_json(table_ref, records)
        if not errors:
            print(f"Inserted {len(records)} rows into {dataset_id}.{table_name}.")
        else:
            print("Errors occurred while inserting rows:", errors)

    except (KeyError, json.JSONDecodeError) as e:
        print("Error parsing Pub/Sub message:", e)
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
