from google.cloud import pubsub_v1
import base64
import json
import pymysql
from datetime import datetime, date
import decimal

publisher = pubsub_v1.PublisherClient()

def main(event, context):
    """Main function to handle incoming event from Pub/Sub."""
    try:
        # Decode Pub/Sub message
        message = base64.b64decode(event['data']).decode('utf-8')
        db_details = json.loads(message)

        # Extract details from payload
        project_id = db_details.get("project_id")
        db_host = db_details.get("db_host")
        db_user = db_details.get("db_user")
        db_password = db_details.get("db_password")
        db_name = db_details.get("db_name")
        table_name = db_details.get("table_name")
        operation = db_details.get("operation")
        second_topic = db_details.get("second_topic")
        fetch_all = db_details.get("fetch_all", False)

        print(f"Connecting to DB: {db_name} at {db_host} with user {db_user}")
        print(f"Second Pub/Sub Topic: {second_topic}")
        print(f"Project ID: {project_id}, Table: {table_name}")

        # Connect to MySQL
        connection = None
        try:
            connection = pymysql.connect(
                host=db_host,
                user=db_user,
                password=db_password,
                database=db_name
            )
            print("Database connection successful.")

            # Perform the requested operation (fetch data)
            if operation == "fetch":
                with connection.cursor() as cursor:
                    # Dynamically construct query based on table_name and fetch_all flag
                    if fetch_all:  # If fetch_all is True, fetch entire data
                        print("Fetching all data from the source table.")
                        if table_name == "customers":
                            query = f"""
                                SELECT id, name, contactNo, location, creation_date 
                                FROM {table_name};
                            """
                        elif table_name == "products":
                            query = f"""
                                SELECT id, product_name, product_desc, price, in_stock, launch_date 
                                FROM {table_name};
                            """
                        elif table_name == "orders":
                            query = f"""
                                SELECT order_id, cust_id, product_id, product_qty, total_price, order_date 
                                FROM {table_name};
                            """
                        else:
                            print(f"Unknown table: {table_name}")
                            return
                    else:  # Default to time-based filtering
                        print(f"Fetching data modified within the last 1 hours from {table_name}.")
                        from datetime import datetime, timedelta
                        time = (datetime.utcnow() - timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S')

                        if table_name == "customers":
                            query = f"""
                                SELECT id, name, contactNo, location, creation_date 
                                FROM {table_name} 
                                WHERE creation_date >= '{time}';
                            """
                        elif table_name == "products":
                            query = f"""
                                SELECT id, product_name, product_desc, price, in_stock, launch_date 
                                FROM {table_name} 
                                WHERE launch_date >= '{time}';
                            """
                        elif table_name == "orders":
                            query = f"""
                                SELECT order_id, cust_id, product_id, product_qty, total_price, order_date 
                                FROM {table_name} 
                                WHERE order_date >= '{time}';
                            """
                        else:
                            print(f"Unknown table: {table_name}")
                            return
                    
                    cursor.execute(query)
                    rows = cursor.fetchall()

                    # Format data for the second Pub/Sub topic
                    processed_data = format_data(rows, table_name)

                    # Publish data to the second Pub/Sub topic
                    publish_to_second_topic(processed_data, project_id, second_topic, table_name)

        except Exception as db_error:
            print(f"Error connecting to the database: {db_error}")
        finally:
            if connection:
                connection.close()

    except Exception as e:
        print(f"Error processing the message: {e}")

def format_data(rows, table_name):
    """Format data based on table_name."""
    if table_name == "customers":
        return [{"id": row[0], "name": row[1], "contactNo": row[2], "location": row[3], "creation_date": row[4]} for row in rows]
    elif table_name == "products":
        return [{"id": row[0], "product_name": row[1], "product_desc": row[2], "price": row[3], "in_stock": row[4], "launch_date": row[5]} for row in rows]
    elif table_name == "orders":
        return [{"order_id": row[0], "cust_id": row[1], "product_id": row[2], "product_qty": row[3], "total_price": row[4], "order_date": row[5]} for row in rows]
    else:
        return []

def convert_datetimes_to_strings(obj):
    """Recursively convert all datetime, date, and Decimal objects in the input to JSON-compatible types."""
    if isinstance(obj, dict):
        return {key: convert_datetimes_to_strings(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [convert_datetimes_to_strings(value) for value in obj]
    elif isinstance(obj, (datetime, date)):
        return obj.isoformat()  # Convert both datetime and date to ISO format string
    elif isinstance(obj, decimal.Decimal):
        return float(obj)  # Convert Decimal to float
    return obj

def publish_to_second_topic(data, project_id, topic, table_name):
    """Publish processed data to the specified Pub/Sub topic."""
    try:
        # Add the table_name field to the payload
        payload = {
            "table_name": table_name,  # Add table_name to the payload
            "data": convert_datetimes_to_strings(data)  # Convert datetime and Decimal objects
        }

        # Create a Pub/Sub topic path using project_id and topic
        topic_path = publisher.topic_path(project_id, topic)
        message = json.dumps(payload).encode("utf-8")  # Corrected: Encode the full payload

        # Publish the message to the topic
        future = publisher.publish(topic_path, data=message)
        future.result()  # Block until the message is published
        print(f"Published processed data with table_name '{table_name}' to {topic} in project {project_id}")

    except Exception as e:
        print(f"Error publishing to topic {topic} in project {project_id}: {e}")
